#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#include "filesys/off_t.h"
#include "lib/user/syscall.h"
/*
System call: internal interrupts or software exceptions
Implement the system call handler
implement your code on syscall.c and syscall.h in userprog folder.
System call numbers for each system call are defined in lib/syscall-nr.h
(BELOW!)
        enum 
        {
            // Projects 2 and later.
            SYS_HALT,                   // Halt: Terminate the OS.
            SYS_EXIT,                   // Exit: Terminate the process. 
            SYS_EXEC,                   // Exec: Execute process with given process name and return that process
            SYS_WAIT,                   // Wait: waits for the given child process
            SYS_CREATE,                 // Create: a file. if success then return TRUE and vice versa
            SYS_REMOVE,                 // Delete: a file. if success then return TRUE and vice versa
            SYS_OPEN,                   // Open: the given file. 
            SYS_FILESIZE,               // Filesize: return the size of given file
            SYS_READ,                   // Read: size bytes from the file, open as fd, into buffer
            SYS_WRITE,                  // Write: size bytes from buffer to the open file fd
            SYS_SEEK,                   // Seek: Changes the next byte in given file to give position value
            SYS_TELL,                   // Tell: returnt the position of the next byte in given file.
            SYS_CLOSE,                  // Close: Close the given file.             
        };
*/

// ----------------------------------------------------------------------
struct file 
  {
    struct inode *inode;        /* File's inode. */
    off_t pos;                  /* Current position. */
    bool deny_write;            /* Has file_deny_write() been called? */
  };
// ---------------------------


void syscall_init (void);
void halt (void);
void exit (int status);
pid_t exec (const char *cmd_line);
int wait (pid_t pid);
bool create (const char *file, unsigned initial_size);
bool remove (const char *file);
int open (const char *file);
int filesize (int fd);
int read (int fd, void *buffer, unsigned size);
int write (int fd, const void *buffer, unsigned size);
void seek (int fd, unsigned position);
unsigned tell (int fd);
void close (int fd);

#endif /* userprog/syscall.h */
